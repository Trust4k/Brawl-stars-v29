from Protocol.Messages.Client.ClientHelloMessage import ClientHelloMessage
from Protocol.Messages.Client.LoginMessage import LoginMessage

packets = {

    10100: ClientHelloMessage,
    10101: LoginMessage,
}
