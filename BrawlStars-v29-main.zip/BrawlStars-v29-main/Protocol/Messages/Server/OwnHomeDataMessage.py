from Logic.ClientHome import LogicClientHome
from Logic.ClientAvatar import LogicClientAvatar
from ByteStream.Writer import Writer
from datetime import datetime

class OwnHomeDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player
        self.maps = [7, 32, 25, 17, 38]

    def encode(self):
        self.writeVInt(2020260)
        self.writeVInt(67238)

        self.writeVInt(self.player.trophies)
        self.writeVInt(self.player.trophies)

        self.writeVInt(122)
        self.writeVInt(200)

        self.writeVInt(1200) #exp

        self.writeScID(28, self.player.profile_icon) #player thumbnails.csv

        self.writeScID(43, self.player.name_color) #name colors

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(122)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeVInt(256)
        self.writeVInt(590552)
        self.writeVInt(50552)
        self.writeVInt(6037352)
        self.writeVInt(200)
        self.writeVInt(200)
        self.writeVInt(5)
        self.writeVInt(77)
        self.writeVInt(180)
        self.writeVInt(430)
        self.writeVInt(975)
        self.writeVInt(2238)

        self.writeVInt(4)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(2)

        self.writeVInt(60)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(200)
        self.writeVInt(-1)
        self.writeVInt(0)

        self.writeVInt(99999)

        self.writeVInt(0)

        self.writeScID(16, self.player.home_brawler)  # selected brawler

        self.writeString("RU")
        self.writeString(self.player.content_creator)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(1)
        for x in range(1):
            self.writeVInt(2)  # current season [0 - tara bazaar, 1 - monsters summer, 2 - STARR Park]
            self.writeVInt(0)  # brawl pass tokens
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(1)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(1)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(4)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(1)
            self.writeVInt(0)
            self.writeVInt(1)
            self.writeVInt(0)

        self.writeVInt(2020260)  # shop timestamp
        self.writeVInt(100)  # 100
        self.writeVInt(10)  # 10
        self.writeVInt(30)  # big box price
        self.writeVInt(3)  # big box multiplier
        self.writeVInt(80)  # mega box price
        self.writeVInt(10)  # mega box multiplier
        self.writeVInt(40)  # token doubler price
        self.writeVInt(1000)  # token doubler amount
        self.writeVInt(550)  # ??
        self.writeVInt(0)
        self.writeVInt(999900)

        self.writeVInt(6)
        for x in [0, 30, 80, 170, 350, 0]:
            self.writeVInt(x)

        self.writeVInt(16)
        for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 20, 21, 22, 23, 24]:
            self.writeVInt(x)

        self.writeVInt(5) # count
        for x in self.maps:
            self.writeVInt(1883183565)  # timestamp
            self.writeVInt(self.maps.index(x) + 1)  # slot
            self.writeVInt(0)
            self.writeVInt(75992)  # time left
            self.writeVInt(10)
            self.writeScID(15, x)  # mapID
            self.writeVInt(3)  # state
            self.writeInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)

        self.writeVInt(0)  # events empty

        self.writeVInt(8)
        for x in [20, 35, 75, 140, 290, 480, 800, 1250]:
            self.writeVInt(x)

        self.writeVInt(8)
        for x in [1, 2, 3, 4, 5, 10, 15, 20]:
            self.writeVInt(x)

        self.writeVInt(0)  # tickets price (useless)

        self.writeVInt(0)  # tickets count (useless)

        self.writeVInt(4)
        for x in [20, 50, 140, 280]:  # coins price
            self.writeVInt(x)

        self.writeVInt(4)
        for x in [150, 400, 1200, 2600]:  # coins count
            self.writeVInt(x)

        self.writeVInt(2)
        self.writeVInt(200)
        self.writeVInt(20)
        self.writeVInt(8640)

        self.writeVInt(10)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(50)
        self.writeVInt(604800)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3)
        self.writeVInt(0)
        self.writeVInt(900104)
        self.writeVInt(0)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        # LogicClientAvatar #

        self.writeVInt(0)
        self.writeVInt(1)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeString(self.player.name)  # Name
        self.writeByte(1)  # NameSetByUser
        self.writeInt(0)

        self.writeVInt(8)  # commodity array count

        self.writeVint(1)
        self.writeVint(23)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(2)  # Tutorial State
        
        self.writeVInt(2)